import 'package:flutter/material.dart';

const kStyleOfCards = TextStyle(
    color: Colors.white,
    fontSize: 20,
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.bold);
